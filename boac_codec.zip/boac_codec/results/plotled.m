%% n=128, n=20
fer = [0.126295, 0.109871, 0.106048, 0.104618, 0.104447];
ber = [0.010368, 0.008450, 0.008120, 0.007963, 0.007918];
ferled = [0.104235, 0.090046, 0.084768, 0.083036, 0.082902];
berled = [0.009715, 0.007744, 0.006886, 0.006662, 0.006646];
ferlst = [0.113677, 0.096933, 0.092653, 0.092855, 0.092653];
berlst = [0.009564, 0.007671, 0.007111, 0.007053, 0.007021];
ferall = [0.096132, 0.080681, 0.070582, 0.071329, 0.068725];
berall = [0.009018, 0.006941, 0.005669, 0.005523, 0.005371];
semilogy(4:8, fer, '-+'); hold on;
semilogy(4:8, ferled, '-x');
semilogy(4:8, ferlst, '-*');
semilogy(4:8, ferall, '-o');
xlabel({'$\log_2M$'}, 'interpreter', 'latex');
ylabel({'Frame-Error-Rate'}, 'interpreter', 'latex');
title({'$p=\epsilon=0.1$, $n=128$, $t=20$, $R=1/3$'}, 'interpreter', 'latex');
legend({'NONE','LED','LAST','LED+LAST'}, 'interpreter', 'latex');
grid on;
axis tight;
set(gca, 'fontsize', 16);

%% n=256, t=40
fer = [0.159006, 0.102400, 0.069133, 0.058288, 0.054065];
ber = [0.013941, 0.008859, 0.005489, 0.004232, 0.003819];
ferled = [0.155529, 0.092552, 0.060335, 0.045994, 0.038965];
berled = [0.015589, 0.008890, 0.005378, 0.003769, 0.002963];
ferlst = [0.155907, 0.097710, 0.065490, 0.053123, 0.046193];
berlst = [0.014041, 0.008671, 0.005344, 0.004049, 0.003342];
ferall = [0.151211, 0.087761, 0.058103, 0.042398, 0.034934];
berall = [0.015127, 0.008430, 0.005278, 0.003576, 0.002752];
figure(2);
semilogy(4:8, fer, '-+'); hold on;
semilogy(4:8, ferled, '-x');
semilogy(4:8, ferlst, '-*');
semilogy(4:8, ferall, '-o');
xlabel({'$\log_2M$'}, 'interpreter', 'latex');
ylabel({'Frame-Error-Rate'}, 'interpreter', 'latex');
title({'$p=\epsilon=0.1$, $n=256$, $t=40$, $R=1/3$'}, 'interpreter', 'latex');
legend({'NONE','LED','LAST','LED+LAST'}, 'interpreter', 'latex');
grid on;
axis tight;
set(gca, 'fontsize', 16);

%% n=512, t=40
fer = [0.222802, 0.119963, 0.080276, 0.060392, 0.048457];
ber = [0.015900, 0.008351, 0.005025, 0.003304, 0.002400];
ferled = [0.216034, 0.114541, 0.072810, 0.050844, 0.040442];
berled = [0.017225, 0.009088, 0.005396, 0.003290, 0.002362];
ferlst = [0.219931, 0.117162, 0.075117, 0.054995, 0.043405];
berlst = [0.016028, 0.008294, 0.004886, 0.003176, 0.002271];
ferall = [0.214226, 0.113174, 0.071052, 0.047355, 0.036148];
berall = [0.016995, 0.009077, 0.005228, 0.003180, 0.002208];
figure(3);
semilogy(4:8, fer, '-+'); hold on;
semilogy(4:8, ferled, '-x');
semilogy(4:8, ferlst, '-*');
semilogy(4:8, ferall, '-o');
xlabel({'$\log_2M$'}, 'interpreter', 'latex');
ylabel({'Frame-Error-Rate'}, 'interpreter', 'latex');
title({'$p=\epsilon=0.1$, $n=512$, $t=40$, $R=1/3$'}, 'interpreter', 'latex');
legend({'NONE','LED','LAST','LED+LAST'}, 'interpreter', 'latex');
grid on;
axis tight;
set(gca, 'fontsize', 16);

%% n=1024, t=40
fer = [0.324461, 0.184173, 0.115056, 0.073416, 0.047531];
ber = [0.022655, 0.012548, 0.007396, 0.004099, 0.002249];
ferled = [0.320000, 0.181947, 0.106312, 0.064128, 0.040882];
berled = [0.024012, 0.013439, 0.007645, 0.004160, 0.002381];
ferlst = [0.320802, 0.182988, 0.110392, 0.067351, 0.045166];
berlst = [0.022609, 0.012613, 0.007317, 0.003968, 0.002283];
ferall = [0.320000, 0.179021, 0.104532, 0.061479, 0.039001];
berall = [0.023522, 0.013155, 0.007573, 0.004018, 0.002386];
figure(4);
semilogy(4:8, fer, '-+'); hold on;
semilogy(4:8, ferled, '-x');
semilogy(4:8, ferlst, '-*');
semilogy(4:8, ferall, '-o');
xlabel({'$\log_2M$'}, 'interpreter', 'latex');
ylabel({'Frame-Error-Rate'}, 'interpreter', 'latex');
title({'$p=\epsilon=0.1$, $n=1024$, $t=40$, $R=1/3$'}, 'interpreter', 'latex');
legend({'NONE','LED','LAST','LED+LAST'}, 'interpreter', 'latex');
grid on;
axis tight;
set(gca, 'fontsize', 16);

