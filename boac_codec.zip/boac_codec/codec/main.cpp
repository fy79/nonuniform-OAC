#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <memory.h>
#include <math.h>
#include <float.h>
#include <iostream>
using namespace std;
typedef unsigned char byte;


#define LED
#define LAST
#define CCS

int globalm;
double lastr;

////////////////////////////////////////////////////////////////////////////////////////////////
static double steps[3];
void setsteps(float p, float r){
    cout<<"r = "<<r<<endl;
    steps[0] = 1-p;
    steps[1] = powf(1-p,r); // (1-p)^r => [0, steps[1])
    steps[2] = 1-powf(p,r); // 1-p^r => [steps[2], 1)
}// [0, steps[2], steps[0], steps[1], 1)

////////////////////////////////////////////////////////////////////////////////////////////////
static double lgp[2], lgq[2];
void setmetrics(float p, float q){
    lgp[0] = log(1-p);
    lgp[1] = log(p);
    lgq[0] = log(1-q);
    lgq[1] = log(q);
}

////////////////////////////////////////////////////////////////////////////////////////////////
struct NODE{
    unsigned low, high, code; int ptr;
    double exmetric, metric;
    NODE *parent, *kids[2];
};
static NODE **paths=NULL;
static NODE *nodes=NULL;
static byte *str=NULL, *str_local=NULL;/* This is the i/o buffer    */
void new_codec(int n, int M){
    str = new byte[n];
    nodes = new NODE[(M<<1)*n+1];
    paths = new NODE*[(M<<1)+1];
    str_local = new byte[n];
}
void free_codec(void){
    delete[] str;
    delete[] nodes;
    delete[] paths;
    delete[] str_local;
}

////////////////////////////////////////////////////////////////////////////////////////////////
const int WIDTH = 32;
const unsigned HRNG = (1U<<(WIDTH-1));    // half of the range
const unsigned QRNG = (1U<<(WIDTH-2));    // quarter of the range
const unsigned MASK = HRNG|(HRNG-1);

////////////////////////////////////////////////////////////////////////////////////////////////
void encode_symbol_last(byte *str, unsigned &low, unsigned &high, int &ptr, int &underflow, byte x){
    double length = (high-low+1.0);
    unsigned len0 = unsigned(length*steps[0]+0.5);
    unsigned len1 = length - len0;
    if(x){
        unsigned sen1 = (1U<<int(log2(len1)));
        low = high - (sen1-1U);
//        lastr = log(sen1/length)/log(len1/length);
//        cout<<double(len1)/double(sen1)<<endl;
//        cout<<len1/length<<endl;
    }else{
        unsigned sen0 = (1U<<int(log2(len0)));
        high = low + (sen0-1U);
//        lastr = log(sen0/length)/log(len0/length);
//        cout<<double(len0)/double(sen0)<<endl;
//        cout<<len0/length<<endl;
    }
//    cout<<lastr<<endl;
    while(!((high^low)&HRNG)){
        str[ptr++] = (low>=HRNG);
        while(underflow){
            str[ptr++] = (low<HRNG);
            underflow--;
        }
        low <<= 1; high <<= 1; high |= 1;
    }
    while((high&QRNG)<(low&QRNG)){
        underflow++;
        low  -= QRNG; low  <<= 1;
        high -= QRNG; high <<= 1; high |= 1;
    }
}
////////////////////////////////////////////////////////////////////////////////////////////////
void encode_symbol(byte *str, unsigned &low, unsigned &high, int &ptr, int &underflow, byte x, bool b=true){
    int a = b+(b&x);
    double length = (high-low+1.0);
    if(x) low += unsigned(length*steps[a]+0.5);
    else  high = low + unsigned(length*steps[a]-0.5);
    while(!((high^low)&HRNG)){
        str[ptr++] = (low>=HRNG);
        while(underflow){
            str[ptr++] = (low<HRNG);
            underflow--;
        }
        low <<= 1; high <<= 1; high |= 1;
    }
    while((high&QRNG)<(low&QRNG)){
        underflow++;
        low  -= QRNG; low  <<= 1;
        high -= QRNG; high <<= 1; high |= 1;
    }
}
int compress(byte *x, int n, int t){
    int ptr=0, underflow=0;
    unsigned low=0, high=MASK;
    memset(str, 0, n*sizeof(byte));
#ifdef LAST
    for(int i=0; i<n-1; i++){
        encode_symbol(str, low, high, ptr, underflow, x[i], i<(n-t));
    }
    encode_symbol_last(str, low, high, ptr, underflow, x[n-1]);
#else
    for(int i=0; i<n; i++){
        encode_symbol(str, low, high, ptr, underflow, x[i], i<(n-t));
    }
#endif
    str[ptr] = 1;
    globalm = ptr;
//    cout<<"m = "<<globalm<<endl;
    return ptr;
}
int compress_local(byte *x, int n, int t){
    int ptr=0, underflow=0;
    unsigned low=0, high=MASK;
    memset(str_local, 0, n*sizeof(byte));
#ifdef LAST
    for(int i=0; i<n-1; i++){
        encode_symbol(str_local, low, high, ptr, underflow, x[i], i<(n-t));
    }
    encode_symbol_last(str_local, low, high, ptr, underflow, x[n-1]);
#else
    for(int i=0; i<n; i++){
        encode_symbol(str_local, low, high, ptr, underflow, x[i], i<(n-t));
    }
#endif
//    cout<<"local m = "<<ptr<<endl;
    return ptr;
}

////////////////////////////////////////////////////////////////////////////////////////////////
byte get_symbol_last(unsigned low, unsigned high, unsigned code){
    double length = (high-low+1.0);
    unsigned len0 = unsigned(length*steps[0]+0.5);
    unsigned len1 = length - len0;
    unsigned sen1 = (1U<<int(log2(len1)));
    unsigned sen0 = (1U<<int(log2(len0)));
    if(code<(low+sen0))         return 0;
    else if(code>(high-sen1))   return 1;
    else                        return 2;
}
void extend_last(int &nNodes, int nPaths, byte y){
    int nbad = 0;
    for(int k=0; k<nPaths; k++){// for each active path
        byte x = get_symbol_last(paths[k]->low, paths[k]->high, paths[k]->code);
        if(x==2){// in error
            NODE *kid = nodes+(nNodes++);
            kid->parent = paths[k]; kid->kids[0] = NULL; kid->kids[1] = NULL;
            paths[k]->kids[0] = kid;
            paths[k] = kid;
            paths[k]->metric = -1e20;
            nbad++;
        }else{// 0/1 node
            NODE *kid = nodes+(nNodes++);
            kid->metric = paths[k]->exmetric + lgq[x^y];// + (1-lastr)*lgp[x];
            kid->parent = paths[k]; kid->kids[0] = NULL; kid->kids[1] = NULL;
            paths[k]->kids[x] = kid;
            paths[k] = kid;
        }
    }
//    cout<<"nbad is "<<nbad<<endl;
}
////////////////////////////////////////////////////////////////////////////////////////////////
NODE *create_root(int &nNodes){
    NODE *root = nodes+(nNodes++);
    root->low = 0; root->high = MASK; root->code = 0; root->ptr = 0;
    for(int i=0; i<WIDTH; i++){
        root->code <<= 1;
        root->code |= str[(root->ptr)++];
    }
    root->exmetric = 0.0;
    root->parent = NULL; root->kids[0] = NULL; root->kids[1] = NULL;
    return root;
}
void remove_symbol(unsigned &low, unsigned &high, unsigned &code, int &ptr, byte x, bool b=true){
    int a = b+(b&x);
    double length = (high-low+1.0);
    if(x) low += unsigned(length*steps[a]+0.5);
    else  high = low + unsigned(length*steps[a]-0.5);
    while(!((high^low)&HRNG)){
        low  <<= 1;
        high <<= 1; high |= 1;
        code <<= 1; code |= str[ptr++];
    }
    while((high&QRNG)<(low&QRNG)){
        low  -= QRNG; low  <<= 1;
        high -= QRNG; high <<= 1; high |= 1;
        code -= QRNG; code <<= 1; code |= str[ptr++];
    }
}
NODE *create_kid(NODE *parent, int &nNodes, byte x, double yinf, const double *ccs, int nseg, float r, bool last){
    NODE *kid = nodes+(nNodes++);
    kid->exmetric = parent->exmetric + yinf + (1-r)*lgp[x]; // update extrinsic metric
    memcpy(kid, parent, 3*sizeof(unsigned)+sizeof(int));// (low, high, code, ptr)
    remove_symbol(kid->low, kid->high, kid->code, kid->ptr, x, r<1);
    double u = ((kid->code) - (kid->low))/((kid->high) - (kid->low) + 1.0);
#ifdef CCS
    if(last){
#ifdef LAST
        kid->metric = kid->exmetric;
#else
        kid->metric = kid->exmetric - log(1+abs(1-2*u));
#endif
    }else{
        kid->metric = kid->exmetric + ccs[int(u*nseg)]; // overall metric
    }
#else
    kid->metric = kid->exmetric;
#endif
    kid->parent = parent; kid->kids[0] = NULL; kid->kids[1] = NULL;
    parent->kids[x] = kid;
    return kid;
}
byte get_symbol(unsigned low, unsigned high, unsigned code, bool b=true){
    double length = (high-low+1.0);
    if((code-low)<unsigned(length*steps[b<<1]+0.5))     return 0;   // < 1-p^r or (1-p)
    else if((code-low)>unsigned(length*steps[b]-0.5))   return 1;   // >= (1-p)^r or (1-p)
    else                                                return 2;
}
void extend(int &nNodes, int &nPaths, byte y, const double *ccs, int nseg, float r, bool last){
    int nKids = nPaths;
    for(int k=0; k<nPaths; k++){// for each active path
        byte x = get_symbol(paths[k]->low, paths[k]->high, paths[k]->code, r<1);
        if(x==2){// fork node
            paths[nKids++] = create_kid(paths[k], nNodes, y, lgq[0], ccs, nseg, r, last);
            paths[k] = create_kid(paths[k], nNodes, !y, lgq[1], ccs, nseg, r, last);
        }else{// 0/1 node
            paths[k] = create_kid(paths[k], nNodes, x, lgq[x^y], ccs, nseg, r, last);
        }
    }
    nPaths = nKids;
}
int compare(const void *a, const void *b){
    if(((*(NODE**)b)->metric)>((*(NODE**)a)->metric))
        return 1;
    else if (((*(NODE**)b)->metric)<((*(NODE**)a)->metric))
        return -1;
    else 
        return 0;
}
void traceback(byte *xr, NODE *leaf, int n){
    NODE *now = leaf;
    for(int i=(n-1); i>=0; i--){
        xr[i] = (now==(now->parent->kids[1]));
        now = (now->parent);
    }
}
int expand(byte *xr, const byte *y, double **ccs, int nccs, int nseg, int M, int n, float r, int t){
    int nNodes=0, nPaths=0;
    paths[nPaths++] = create_root(nNodes);
#ifdef LAST
    for(int i=0; i<n-1; i++){
        extend(nNodes, nPaths, y[i], ccs[max(1,min((n-t-i),nccs))-1], nseg, pow(r,i<(n-t)), i==(n-1));
        if((i<(n-t-1)) && (nPaths>=M)){
            qsort(paths, nPaths, sizeof(NODE*), compare); // sort paths in the descending order of metric
            nPaths = M;
        }
    }
    extend_last(nNodes, nPaths, y[n-1]);
#else
    for(int i=0; i<n; i++){
        extend(nNodes, nPaths, y[i], ccs[max(1,min((n-t-i),nccs))-1], nseg, pow(r,i<(n-t)), i==(n-1));
        if((i<(n-t-1)) && (nPaths>=M)){
            qsort(paths, nPaths, sizeof(NODE*), compare); // sort paths in the descending order of metric
            nPaths = M;
        }
    }
#endif
       
#ifdef LED
    qsort(paths, nPaths, sizeof(NODE*), compare); // sort paths in the descending order of metric
    for(int j=0; j<nPaths; j++){
        traceback(xr, paths[j], n);
        memset(str_local, 0, sizeof(byte)*n);
        if(globalm==compress_local(xr,n,t)){
            break;
//            if(!memcmp(str,str_local,globalm)){
//                break;
//            }else{
////                printf("%d: getup\n", j);
//            }
        }else{
//            printf("%d: laydown\n", j);
        }
    }
#else
    for(int j=1; j<nPaths; j++){
        if((paths[j]->metric) > (paths[0]->metric)){
            paths[0] = paths[j];
        }
    }
    traceback(xr, paths[0], n);
//    memset(str_local, 0, sizeof(byte)*n);
//    if(globalm==compress_local(xr,n,t)){
//        if(!memcmp(str,str_local,globalm)){
//            cout<<"good"<<endl;
//        }else{
//            cout<<"bad"<<endl;
//        }
//    }else{
//        cout<<"worse"<<endl;
//    }
#endif
    return nNodes;
}

// (10,111... - 00,000...) = (11,000... - 00,000...) - 1    = 3*N/4 - 1
// (10,000... - 00,111...) = (10,000... - 01,000...) + 1    = N/4 + 1
// (11111... - 00000...)                                    = N - 1
// (11000... - 00111...) = (11000... - 01000...) + 1        = N/2 + 1

void getccs(double **ccs, float p, float r, int n, int m){
    for(int j=0; j<m; j++){
        ccs[0][j] = 1;
    }
    for(int i=1; i<n; i++){
        memset(ccs[i], 0, m*sizeof(double));
        double scale0 = pow(1-p,-r);    // (1-p)^(-r)
        for(int j=0; j<int(ceil(m/scale0)); j++){
            /* j<ceil(m(1-p)^r) guarantees alpha<m */
            double alpha=j*scale0, beta=alpha+scale0;
            double temp = (alpha>0) ? (ceil(alpha)-alpha)*ccs[i-1][int(ceil(alpha))-1] : 0;
            if(beta>=m){
                for(int k=int(ceil(alpha)); k<m; k++){
                    temp += ccs[i-1][k];
                }
            }else{
                for(int k=int(ceil(alpha)); k<int(beta); k++){
                    temp += ccs[i-1][k];
                }
                temp += (beta-int(beta))*ccs[i-1][int(beta)];
            }
            ccs[i][j] = (1-p)*temp;
        }
        double scale1 = pow(p,-r), shift = m*(1-pow(p,r));
        for(int j=int(shift); j<m; j++){
            /* j>=floor(m(1-p^r)) guarantees beta>0 */
            double alpha=(j-shift)*scale1, beta=alpha+scale1;
            double temp = (beta<m) ? (beta-int(beta))*ccs[i-1][int(beta)] : 0;
            if(alpha<=0){
                for(int k=0; k<int(beta); k++){
                    temp += ccs[i-1][k];
                }
            }else{
                temp += (ceil(alpha)-alpha)*ccs[i-1][int(ceil(alpha))-1];
                for(int k=int(ceil(alpha)); k<int(beta); k++){
                    temp += ccs[i-1][k];
                }
            }
            ccs[i][j] += p*temp;
        }
    }
}

int count_errors(const byte *rec, const byte *src, int n){
    int nerrs = 0;
    for (int i = 0; i < n; i++){
        nerrs += (rec[i]^src[i]);
    }
    return nerrs;
}

int main(int argc, char *argv[]){
    int n=(1<<10), t=40, M=(1<<8);
    float p=0.1, q=0.1, R=1/3.0;
    setmetrics(p,q);
    float hp = -p*log2(p)-(1-p)*log2(1-p), r=(n*R/hp-t)/(n-t);
    setsteps(p,r);
    byte *x=new byte[3*n], *y=x+n, *xr=y+n;
    new_codec(n,M);
    
    /* initialize CCS array */
//    FILE *fp = fopen("ccs.txt", "wt");
    int nccs=(1<<7), nseg=(1<<12);
    double **ccs = new double*[nccs];
    for(int i=0; i<nccs; i++){// for each stage
        ccs[i] = new double[nseg];
    }
    getccs(ccs, p, r, nccs, nseg);
    for(int i=0; i<nccs; i++){
        for(int j=0; j<nseg; j++){
//            fprintf(fp, "%f\n", ccs[i][j]);
            ccs[i][j] = log(ccs[i][j]);
        }
    }
//    fclose(fp);
    cout<<"CCS initialization over!"<<endl;

    srand(0);
    // loop for trials
    int nefs = 0, nebs = 0, ntries = 0;
    while(1){
        for(int i=0; i<n; i++){
            x[i] = (rand()<RAND_MAX*p);
            y[i] = x[i]^(rand()<RAND_MAX*q);
        }
        compress(x,n,t);
        expand(xr,y,ccs,nccs,nseg,M,n,r,t);
        
        int temp = count_errors(x, xr, n);
        nefs += (temp>0);
        nebs += temp;
        ntries++;
        if((ntries>=(1<<16)) || (nefs>=(1<<8))){
            break;
        }
    }
    printf("FER = %f\nBER = %f\n", nefs/float(ntries), nebs/float(n*ntries));
    free_codec();
    delete[] x;
    for (int i=0; i<nccs; i++) {
        delete[] ccs[i];
    }
    delete[] ccs;

//    clock_t start = clock();
//    clock_t finish = clock();
//    float duration = (float)(finish-start)/CLOCKS_PER_SEC;
//    printf("%.0f ms\n", duration*1e3);

    return 0;
}
